# ESE4009 

Auto Rotob using pixy to motiner surrounding and connected to pocket beaglebone which is give command to LPC to run motor in desire direction.
Motor Can Drive In Both Direction.
